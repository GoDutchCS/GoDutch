package com.example.godutch;

public class Constants {
    public static final String SERVER_IP = "http://192.249.19.243:9280"; //권해찬
//    public static final String SERVER_IP = "http://192.249.19.243:9480"; // 김경연
}
